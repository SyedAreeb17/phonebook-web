const express = require('express')

const app = express()


app.set('view-engine','ejs')



app.get('/homepage' , (req,res) => {
    res.render('homepage.ejs')

})

app.get("/areeb.jpeg", (req, res) => {
    res.sendFile(path.join(__dirname, "./views/areeb.jpeg"));
  });

app.use(express.static(__dirname + '/public'));

app.listen(3000)
